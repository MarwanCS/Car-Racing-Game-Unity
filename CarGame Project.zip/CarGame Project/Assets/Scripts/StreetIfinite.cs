﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StreetIfinite : MonoBehaviour {
    Vector2 offset;
    public float speedStreet=1.5f;
    public int rekxstnyXerayyStreet;
    public bool rexstnyGameOver=false;
    public int rexstnyMawayWastanLaKatyGameOver = 2;
    public bool yakJarCameraShak = true;
    public CameraShake larynawayShasha;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (rexstnyGameOver == true)
        {
            Time.timeScale = 0.5f;
            rexstnyMawayWastanLaKatyGameOver += 1;
            
            if (yakJarCameraShak == true)
            {
                StartCoroutine(larynawayShasha.Shake(1f, 0.15f));
                yakJarCameraShak = false;
            }
        }
        if (rexstnyMawayWastanLaKatyGameOver % 40 == 0)
        {
            Application.LoadLevel("gameOverScene");
            Time.timeScale = 1;
            rexstnyGameOver = false;
            rexstnyMawayWastanLaKatyGameOver = 1;
        }
        if (rekxstnyXerayyStreet % 1000 == 0) // bo away wrda wrda xerayy jadaka zyad bkat
        {
            speedStreet += 0.2f;
        }
        // bo jwlla dan ba jadaka ba ifinifty
        offset = new Vector2(0, Time.time * speedStreet);
        GetComponent<Renderer>().material.mainTextureOffset = offset;     // bo jwlla dan ba jadaka ba ifinifty
        rekxstnyXerayyStreet++;
    }
}
