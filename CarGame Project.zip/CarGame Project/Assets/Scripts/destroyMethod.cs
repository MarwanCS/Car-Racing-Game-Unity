﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class destroyMethod : MonoBehaviour {

	void Start () {
      
	}
	
	// Update is called once per frame
	void Update () {
        

	}
    private void OnCollisionEnter2D(Collision2D coll)
    {

        //bo away ka player bar para kawtyt paraka namenet wata player tagy Finishy lasara wa am methoda lasar coina
        if (coll.gameObject.tag == "Finish")
        {

            Destroy(gameObject);
            
        }
    }


}
