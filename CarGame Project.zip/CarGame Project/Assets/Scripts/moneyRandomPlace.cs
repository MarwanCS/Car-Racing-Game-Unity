﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moneyRandomPlace : MonoBehaviour {
    public GameObject para;
    
    public int rexstn = 0;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        rexstn++;
        if (rexstn % 120 == 0)
        {
            Vector3 RandomPlace = new Vector3(Random.Range(-3.27f, 3.26f), transform.position.y);  // bo awawy ba randomy shweny para dyary bkat
            Instantiate(para, RandomPlace, transform.rotation);

        }
    }
}
