﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class getScoreP1 : MonoBehaviour {
    public Text scorePlayer1;
	// Use this for initialization
	void Start () {
        // bo away ka datatay playeer1 warbgret ka scoreyakayaty w byxata naw UI.Text ka am koday lasara
        scorePlayer1.text="SCORE : "+PlayerPrefs.GetInt("scoreP1");
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
