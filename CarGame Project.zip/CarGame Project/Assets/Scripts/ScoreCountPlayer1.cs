﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreCountPlayer1 : MonoBehaviour {

    public int score = 0;

    public Text ScoreTextPlayer1;
    int rexstn;
    public  bool gameOver;
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (gameOver == false)
        {
            rexstn++;
            if (rexstn % 40 == 0)
            {
                score++;
                ScoreTextPlayer1.text = "SCORE :" + score;

            }
        }
    }

    public void scoreUpdate()
    {
        score += 5;
    }
    public void gameOverCar1()
    {
        PlayerPrefs.SetInt("scoreP1", score);
    }
}
