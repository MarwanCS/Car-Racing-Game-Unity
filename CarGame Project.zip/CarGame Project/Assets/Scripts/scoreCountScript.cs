﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class scoreCountScript : MonoBehaviour {

   public  int score = 0;

    public Text ScoreText;
    int rexstn;
    public static bool gameOver;
    void Start () {
        
    }
	
	// Update is called once per frame
	void Update () {
        if (gameOver == false)
        {
            rexstn++;
            if (rexstn % 40 == 0)
            {
                score++;
                ScoreText.text = "SCORE :" + score;
                
            }
        }
    }

    public void scoreUpdate()
    {
        score += 5;
    }

    public void gameOverAccess()
    {
        if (score > PlayerPrefs.GetInt("highScore"))            // bo away bzanet aya aw scoreyay ka payam krdwa zyatra la high score yan na 
            PlayerPrefs.SetInt("highScore", score);

        PlayerPrefs.SetInt("Score", score);
       
    }
   

}
