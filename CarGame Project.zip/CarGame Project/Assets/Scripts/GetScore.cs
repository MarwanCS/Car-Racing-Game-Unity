﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GetScore : MonoBehaviour {
    public Text scoreFinish;
   
   
    // Use this for initialization
    void Start () {
       //wargrtnaway scorre player la yary 1 nafary
        scoreFinish.text = "SCORE :" + (PlayerPrefs.GetInt("Score")).ToString();
       
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
