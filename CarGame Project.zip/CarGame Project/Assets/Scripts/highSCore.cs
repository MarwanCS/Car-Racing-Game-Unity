﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class highSCore : MonoBehaviour {

    public Text highScore;
    void Start()
    {
        highScore.text = "HIGH SCORE :" + (PlayerPrefs.GetInt("highScore")).ToString();
    }

    // Update is called once per frame
    void Update () {
		
	}
}
