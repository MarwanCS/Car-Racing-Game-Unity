﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class CarControl  : MonoBehaviour {

    Vector2 pos;     public float pechkrdnawaySayaraSpeed=7;
    public Text scoreOver;
    public scoreCountScript over;
    public AudioSource coinAudio;
    public AudioSource destroySound;
    public StreetIfinite objLarynawa;
    public GameObject windowCrack;
    // Use this for initialization
    void Start () {
        pos = transform.position;



    }
	
	// Update is called once per frame
	void Update () {
        pos.x += Input.GetAxis("rastWchap") *Time.deltaTime*pechkrdnawaySayaraSpeed;
        pos.y -= Input.GetAxis("peshWdwa") * pechkrdnawaySayaraSpeed * Time.deltaTime;
        pos.x= Mathf.Clamp(pos.x, -3.87f, 3.87f);         // bo away natwanyt law snwra zyatr bjwleyt lasar tawaray x
        pos.y = Mathf.Clamp(pos.y, -4.8f, 4.8f);         // bo away natwanyt law snwra zyatr bjwleyt lasar tawaray y
        transform.position = pos;
        

        
	}
   

    private void OnCollisionEnter2D(Collision2D coll)
    {
     
        //bo away har sayarak bar game obj kawt yaksar GAME OVER bet
        if (coll.gameObject.tag == "wnBWn")
        {
            destroySound.Play();
            Destroy(gameObject,0.1f);
            over.gameOverAccess();    // bo away ka doram yaksar scoreyakam waerbgret w wa bzanet aya high score ya yan na 
            objLarynawa.rexstnyGameOver = true;
            Instantiate(windowCrack, transform.position, transform.rotation); //window crack



        }
        //bo away har katek parat xward score+5 bkret
        if (coll.gameObject.tag == "scorePara")
        {
            coinAudio.Play();       // bo away ka param xwar dangek bet
            over.scoreUpdate();   // bo away ka paarm xwar +5 bkret score
        }
    }
}
