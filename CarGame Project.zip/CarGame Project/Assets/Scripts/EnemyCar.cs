﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyCar : MonoBehaviour {

    public  GameObject []enemyCar;
    public int carNum;
   public int rexstniHatnyEnemyCar=1;
    public int kamkrdn ;
	void Start () {

        kamkrdn = 50;

    }

    // Update is called once per frame
    void Update () {
        if (rexstniHatnyEnemyCar % kamkrdn == 0)
        {
            carNum = Random.Range(0, 8);  //ba randomy sayarayak haldabzheret
            Vector3 RandomPlace = new Vector3(Random.Range(-3.87f, 3.88f), transform.position.y);   //bo dyary krdny tawaray x ba random wa y wakw xoy
            Instantiate(enemyCar[carNum], RandomPlace, transform.rotation); // datwanyn obj+ position y emty objectejy laregawadyary bkayn
        }
        
        if(rexstniHatnyEnemyCar%500==0 && kamkrdn>25)     // bo awawy wrda wrda yaryaka qwrs bet w sayaray zyatr bet
        {
            kamkrdn--;
        }
        rexstniHatnyEnemyCar++;
    }
}
