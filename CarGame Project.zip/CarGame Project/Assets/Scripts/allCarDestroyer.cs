﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class allCarDestroyer : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    private void OnCollisionEnter2D(Collision2D coll)
    {

       //bo destroy krdny hamw sayarakan la kotayda wa am methoda lasar hamw sayarakana bo away ka bar object y destroyer kawtn ka tagy pleyr  lasara rastwxo sayarakan lanaw bchn
        if (coll.gameObject.tag == "Player")
        {
            Destroy(gameObject);
        }
    }
}
