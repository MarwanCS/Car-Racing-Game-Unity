﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

    
public class GoScenes : MonoBehaviour {

//bo goreny scene akan ka zyatr lasar buttonakann am methoda 
    public void playMultipleGame(string scene)
    {
        Application.LoadLevel(scene);
    }
    public void playGame(string scene)
    {
        Application.LoadLevel(scene);
    }
    public void aboutGame(string scene)
    {
        Application.LoadLevel(scene);
    }
    public void HomeGame()
    {
        Application.LoadLevel("StartScene");
    }
    public void ExitGame()
    {
        Application.Quit();
    }
   
}
