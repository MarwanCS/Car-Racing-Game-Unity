﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class multipleCarControl2 : MonoBehaviour {

    Vector2 pos; public float pechkrdnawaySayaraSpeed = 7;
    public multipleControlCar objAyaHardwkyanMrdn;
    public ScoreCountPlayer2 addScore2;
    public AudioSource coinAudio;
    public AudioSource destroyCar;
    // Use this for initialization
    void Start()
    {
        pos = transform.position;


    }

    // Update is called once per frame
    void Update()
    {
        pos.x += Input.GetAxis("Horizontal") * Time.deltaTime * pechkrdnawaySayaraSpeed;
        pos.y -= Input.GetAxis("Vertical") * pechkrdnawaySayaraSpeed * Time.deltaTime;
        pos.x = Mathf.Clamp(pos.x, -6.7f, 6.26f);
        pos.y = Mathf.Clamp(pos.y, -8.29f, 8.29f);
        transform.position = pos;
        
    }
    private void OnCollisionEnter2D(Collision2D coll)
    {

        //bo away har sayarak bar game obj kawt yaksar GAME OVER bet
        if (coll.gameObject.tag == "wnBWn")
        {
            addScore2.gameOverP2();  //bo away har katek am sayaraya  dora score yakay save bkat 
            destroyCar.Play(); // dangy doran 
            Destroy(gameObject);// bo lanawchwny sayaraka agar bar sayaray tr kawt
            addScore2.gameOver = true;  // bo away scoreyaka law xalada bostetw etr zyad nakat
            if (objAyaHardwkyanMrdn.nasarawayAyaHardwkyanMrdn == 1)       // agar yak bw awa nyshanay awaya ka hardw sayaraka dorawn boya yaksar scene game over pishan dadat
                Application.LoadLevel("GameOverMultiple");
            else// agar na daykat ba yak wata sayaray yakam dora
                objAyaHardwkyanMrdn.nasarawayAyaHardwkyanMrdn = 1;
        }
        if (coll.gameObject.tag == "scorePara")
        {
            coinAudio.Play();      // bo away ka param xwar dangek bet
            addScore2.scoreUpdate();// bo away ka paarm xwar +5 bkret score
        }

    }
}
