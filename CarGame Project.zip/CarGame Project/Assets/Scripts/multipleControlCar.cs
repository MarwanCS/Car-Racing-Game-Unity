﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class multipleControlCar : MonoBehaviour {

    Vector2 pos; public float pechkrdnawaySayaraSpeed = 7;
    public ScoreCountPlayer1 addScore1;
    public AudioSource coinAudio;
    public AudioSource destroyCar;
    public int nasarawayAyaHardwkyanMrdn=0;
    // Use this for initialization
    void Start()
    {
        pos = transform.position;


    }

    // Update is called once per frame
    void Update()
    {
        pos.x += Input.GetAxis("rastWchap") * Time.deltaTime * pechkrdnawaySayaraSpeed;
        pos.y -= Input.GetAxis("peshWdwa") * pechkrdnawaySayaraSpeed * Time.deltaTime;
        pos.x = Mathf.Clamp(pos.x, -6.7f, 6.26f);
        pos.y = Mathf.Clamp(pos.y, -8.29f, 8.29f);
        transform.position = pos;
    }

    private void OnCollisionEnter2D(Collision2D coll)
    {

        //bo away har sayarak bar game obj kawt yaksar GAME OVER bet
        if (coll.gameObject.tag == "wnBWn")
        {
            destroyCar.Play();
            Destroy(gameObject);
            addScore1.gameOverCar1();
            addScore1.gameOver = true;
            if (nasarawayAyaHardwkyanMrdn == 1)
                Application.LoadLevel("GameOverMultiple");
            else
            nasarawayAyaHardwkyanMrdn = 1;
        }
        if (coll.gameObject.tag == "scorePara")
        {
            coinAudio.Play();
            addScore1.scoreUpdate();
        }
    }
}
