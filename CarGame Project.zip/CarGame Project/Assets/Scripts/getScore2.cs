﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class getScore2 : MonoBehaviour {

    public Text scorePlayer2;
    // Use this for initialization
    void Start()
    {
        // bo away ka datatay playeer 2 warbgret ka scoreyakayaty w byxata naw UI.Text ka am koday lasara
        scorePlayer2.text = "SCORE : " + PlayerPrefs.GetInt("scoreP2");
    }

    // Update is called once per frame
    void Update()
    {

    }
}
