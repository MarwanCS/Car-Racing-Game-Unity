﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreCountPlayer2 : MonoBehaviour {

    public int score = 0;

    public Text ScoreTextPlayer2;        
    int rexstn;
    public  bool gameOver;
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (gameOver == false)
        {
            rexstn++;
            if (rexstn % 40 == 0)        // bo rekxstny katy zyadbwny  score
            {
                score++;
                ScoreTextPlayer2.text = "SCORE :" + score;
               
            }
        }
    }

    public void scoreUpdate()
    {
        score += 5;
    }
    public void gameOverP2()
    {
        PlayerPrefs.SetInt("scoreP2" , score); // bo away ka doram la methodeky trawaw cally bkret w score xazn bkat
    }
}
