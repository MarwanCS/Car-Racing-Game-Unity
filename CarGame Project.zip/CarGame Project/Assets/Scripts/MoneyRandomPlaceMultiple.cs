﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoneyRandomPlaceMultiple : MonoBehaviour {
    public GameObject para;

    public int rexstn = 0;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        rexstn++;
        if (rexstn % 120 == 0)
        {
            Vector3 RandomPlace = new Vector3(Random.Range(-6.7f, 6.26f), transform.position.y);
            Instantiate(para, RandomPlace, transform.rotation);

        }
    }
}
