﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyCarmultiple : MonoBehaviour {
    public GameObject[] enemyCar;
    public int carNum;
    public int rexstniHatnyEnemyCar = 1;
    public int kamkrdn;
    void Start()
    {

        kamkrdn = 50;

    }

    // Update is called once per frame
    void Update()
    {
        if (rexstniHatnyEnemyCar % kamkrdn == 0)
        {
            carNum = Random.Range(0, 7);
            Vector3 RandomPlace = new Vector3(Random.Range(-6.7f, 6.26f), transform.position.y);
            Instantiate(enemyCar[carNum], RandomPlace, transform.rotation);
        }

        if (rexstniHatnyEnemyCar % 500 == 0 && kamkrdn > 25)
        {
            kamkrdn--;
        }
        rexstniHatnyEnemyCar++;
    }
}
