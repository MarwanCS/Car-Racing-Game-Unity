﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moveCarEnemy : MonoBehaviour {
    public float speedEnemyCar = 7;
    Vector3 pos;
    int rexstnyXerayyCar = 1;
    // Use this for initialization
    void Start () {
        pos = transform.position;
    }
	
	// Update is called once per frame
	void Update () {
       if(rexstnyXerayyCar%1000==0)
        {
            speedEnemyCar += 0.1f;
        }
       //am methoda tanha bo jwlandny sayarakan ka lasar xwdy sayarakann nak objectaka
        pos.y -= Time.deltaTime * speedEnemyCar;
        transform.position = pos;
        rexstnyXerayyCar++;
    }
}
