﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moneyMove : MonoBehaviour {

    public float speedcoin = 2;
    Vector3 pos;
    // Use this for initialization
    void Start () {
        pos = transform.position;
	}
	
	// Update is called once per frame
	void Update () {
        //bp jwlany paraka ka lasar xwdy rasmy coinaka danrawa
        pos.y -= Time.deltaTime * speedcoin;
        transform.position = pos;
       
    }
}
